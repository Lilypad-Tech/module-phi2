This is an example of a Lilypad Module. The Phi-2 module used in this is example can be found here on [huggingface](https://huggingface/amgadhasan/phi-2)

a Link to a demo video using this model can be found here on [youtube](https://x.com/Lilypad_Tech/status/1737685808860274820?s=20)

## Steps to relicate on Lilypad

## Code snipbits

## Outline of modifications